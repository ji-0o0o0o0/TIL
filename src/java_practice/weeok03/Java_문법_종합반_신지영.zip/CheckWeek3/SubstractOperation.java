package java_practice.weeok03.CheckWeek3;

public class SubstractOperation extends AbstractOperation{
    @Override
    public double operate(int a, int b) {
        return  a-b;
    }
}
