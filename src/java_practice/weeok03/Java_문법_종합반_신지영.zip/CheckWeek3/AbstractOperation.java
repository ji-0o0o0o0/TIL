package java_practice.weeok03.CheckWeek3;

public abstract class AbstractOperation {
    public abstract double operate(int a, int b);
}
