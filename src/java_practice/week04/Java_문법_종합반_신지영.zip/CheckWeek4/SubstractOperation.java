package java_practice.week04.CheckWeek4;

public class SubstractOperation extends AbstractOperation {
    @Override
    public double operate(int a, int b) {
        return  a-b;
    }
}
