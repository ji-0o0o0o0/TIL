package java_practice.week04.CheckWeek4;

public abstract class AbstractOperation {
    public abstract double operate(int a, int b);
}
