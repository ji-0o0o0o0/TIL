package java_practice.week04.CheckWeek4;

public class MultiplyOperation extends AbstractOperation {
    @Override
    public double operate(int a, int b) {
        return a*b;
    }
}
